
		<footer>
			<div class="container-fluid end pt-4 pb-4 text-center">
						<h6>Connect with us</h6>
						<h1 class="mb-4">
						<span class="fab fa-facebook-square mr-5 ml-5"></span>
						<span class="fab fa-instagram-square mr-5"></span>
						<span class="fab fa-twitter-square mr-5"></span>
					</h1>

				<h6>78 Old Ring Road Off Abak Road, Uyo
Akwa Ibom State, Nigeria.</h6>
				<h6>@2020 Trinity Missionary Fellowship</h6>
			</div>
		</footer>
   </body>
</html>

<?php
//unset($_SESSION['flash_errors']);
