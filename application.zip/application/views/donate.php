

<?php include 'header.php';?>
<!-- Carousel -->
<div id="reminder" class="container-fluid">
  <center><div id ="partnerdiv" class="containe item-center"><b>PARTNER/DONATE</b></div></center>
    <div class="row">
      <div class="col-lg-6">

        <!--carousel indicators -->
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
        </div>

        <!-- carousel slides -->
       <div class="carousel-inner">
        <div class="carousel-item active">
        <img class="d-block w-100" src="pictures/photo/new7.png" alt="First slide">
        <div class="carousel-caption">
        The ministry of Trinity Missionary Fellowship is made possible with the participation of many people who desire to put their strengths, abilities, and resources towards the cause of changing hearts and lives through the Gospel of Jesus Christ. 
        </div>
        </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="pictures/photo/new6.png" alt="Second slide">
        <div class="carousel-caption">
        Your support makes it possible for Trinity Missionary Fellowship to remain a Beacon of Light to the lost, the Voice of Hope to our nation and the Hands and Feet of Jesus to our world. 
        </div>
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="pictures/photo/new5.png" alt="Third slide">
        <div class="carousel-caption">
        Please consider planting into the ministry of The Trinity Missionary Fellowship and join us in our mission to save the lost, and impact millions of lives through the Gospel of Jesus Christ, and care for people in need and transform the world for the love of Christ and for the glory of His name. 
        </div>
      </div>
      </div>

      <!-- carousel prev and next buttons -->
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- To donate -->

    <div class="col-lg-6">
    <div class="container-fluid">
      <center><h5>To donate,</h5></center>
      <div class="row">
        <div class="col-sm-6">
          <label>Click to call:</label></br>
          <a href="tel: +234-703-984-3199">+2347039843199</a>, <a href="tel: +234-803-788-1693">+2348037881693</a></br>
        </div>
        <div class="col-sm-6">
          <label>Or click to email:</label></br>
          <a href="mailto: donate@trinityfellowship.com">donate@trinityfellowship.com</a>
        </div>
      </div>
    </div>



    <!-- Email reminder form -->
<div class="container-fluid">
  <form id="" method="post" action="">
    <h6>Also, sign up for email reminders</h6>
    <div class = "form-row">
      <div class="form-group col-sm-6">
        <label>First Name:*</label>
        <input type="text" class="form-control" name = "firstname" id="inputName" placeholder="First Name">
      </div>

<?php if (isset($_SESSION['flash_errors']['firstname'])) {
    echo '<span style="color:red">' . $_SESSION['flash_errors']['firstname'] . '</span><br>';
}?>

      <div class="form-group col-sm-6">
        <label>Amount:*</label>
        <input type="number" min ="1" step = "any" class="form-control" name = "amount" id="inputName" placeholder="Amount">
      </div>

<?php if (isset($_SESSION['flash_errors']['email'])) {
    echo '<span style="color:red">' . $_SESSION['flash_errors']['email'] . '</span><br>';
}?>

    </div>
    <div class = "form-row">
    <div class="form-group col-sm-6">
      <label>Remind me on:*</label>
      <input type="Date" class="form-control" name = "remindmeon" id="inputName" placeholder="Date">
   </div>

<?php if (isset($_SESSION['flash_errors']['firstname'])) {
    echo '<span style="color:red">' . $_SESSION['flash_errors']['firstname'] . '</span><br>';
}?>

    <div class="form-group col-sm-6">
      <label>Email:</label>
      <input type="text" class="form-control" name = "email" id="inputName" placeholder="Email">
    </div>

<?php if (isset($_SESSION['flash_errors']['email'])) {
    echo '<span style="color:red">' . $_SESSION['flash_errors']['email'] . '</span><br>';
}?>

    </div>

      <div class="form-group">
        <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck">
        <label style = "color: gray;"class="form-check-label" for="gridCheck">
       By submiting your credentials, you agree to receive weekly content from Trinity Missionary Fellowship
        </label>
        </div>
      </div>
        <center><button type="submit" ckecked class="btn btn-primary">Sign Up</button></center>
  </form>
</div>
</div>
</div>
</div>

 
<?php include 'footer.php';?>