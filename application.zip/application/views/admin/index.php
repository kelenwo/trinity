<?php
//require_once(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'init.php');

echo '<html>
<head></head>

<body>
<div>ADMIN CPANEL</div>
<div><a href="subscriptions.php">Manage Subscriptions</a></div>
</body>
</html>';